import {env} from 'cloudflare:workers';
export function database() {
  if (!env.DB) throw new Error('Project storage is unavailable. Export your project to keep your work.');
  return env.DB;
}
