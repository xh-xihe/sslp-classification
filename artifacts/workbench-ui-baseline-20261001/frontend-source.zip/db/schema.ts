import {sqliteTable,text,integer,primaryKey} from 'drizzle-orm/sqlite-core';
export const projects=sqliteTable('research_projects',{
  owner:text('owner').notNull(), id:text('id').notNull(),
  title:text('title').notNull(), body:text('body').notNull(),
  revision:integer('revision').notNull(), updatedAt:text('updated_at').notNull(),
},table=>[primaryKey({columns:[table.owner,table.id]})]);
