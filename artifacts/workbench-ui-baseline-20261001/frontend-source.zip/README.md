﻿# SSLP Workbench

An English research workspace for quantum codes. Projects, candidate inputs, exact checks,
phase circuits, run comparisons, notes and proof records share one working surface. The
Class 36 manuscript example is a reusable template.

## Research workflow

1. Create a project from the editable repetition-code starter or the Class 36 template.
2. Import a code JSON, edit the full definition, or change individual amplitude phases.
3. Run exact checks. Inspect normalization, every Pauli compression and its contribution terms.
4. Change the input and run again. Compare snapshots or restore an earlier input.
5. Save the project to your account, or export a portable project / code / report.
6. For compatible six-qubit inputs, connect the local companion to submit model, exact or Lean jobs.

Project storage uses D1, keyed by the platform-authenticated user. Writes check the expected
revision and reject conflicting saves. Session storage is only temporary draft recovery.
Save is explicit. Each project retains up to 20 input snapshots; comparisons recompute the
arithmetic, and imported status labels or credentials never become evidence.

## Supported mathematics

- Sparse codewords with 1–6 physical qubits, logical dimension 1–4 and target distance at most 3.
- Eight integer amplitude coordinates in Z[sqrt(2), sqrt(3), i], with a configurable common
  scale 1/sqrt(denominator). Coordinates and denominator are bounded by 1,000,000.
- Exact BigInt normalization and Hermitian Pauli KL checks, with leftmost bit = qubit 1.
- Diagonal physical phase layers with modulus 2–64; support fibers establish a sufficient
  diagonal logical action test. Failure does not disprove general code-space preservation.
- Circuit playback, logical-state controls for K=2, support inspection and the full encoding matrix.
- A separate exact Class 36 probability-slice tool (visible on its canonical input).
- K=1 results use the stated KL definition and do not imply an unrestricted Singleton bound.

Browser arithmetic is not Lean certification. The local proof adapter still targets the
canonical six-qubit construction. Arbitrary imported codes and alternative logical bases
need a suitable adapter. The archived certificate does not cover an elementary-gate encoder,
minimal gate order, classification completeness or the whole manuscript.

The assistant defaults to the configured open model and retains optional closed providers.
Model text, tool records and kernel evidence remain separate. Local connection credentials
stay in memory and are excluded from saved projects and exports. The Python companion lives
in the parent research repository; it is not a hosted remote compute service.

## Formats

`sslp.research-code.v1` stores n, k, distance, denominator, q, angles and sparse words.
Each word entry has a bitstring and eight integer coordinates. `sslp.project.v1` exports
project metadata, notes, current code and input snapshots. Imports also accept the former
`sslp.code-instance.v1` and `sslp.experiment.v2` formats. Reports use
`sslp.research-report.v1` with BigInt coordinates serialized as decimal strings.

## Development and verification

Use native Node 24 or newer compatible Node (minimum 22.13). No Linux environment is required.

```text
npm install
npm run typecheck
npm test
npm run build
npm start -- --port 5174
```

The built preview uses the Worker runtime for D1. For schema changes, run `npm run db:generate`.
Apply each pending migration once to the local preview database after building:

```text
node node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_vengeful_sprite.sql
```

The private hosted Site receives authenticated identity from the platform. The standalone
built preview does not simulate sign-in. Storage integration tests send local test identities:

```text
node tests/project-api.integration.mjs
```

That script is restricted to the loopback preview at port 5174. It tests unauthenticated and
cross-origin rejection, ownership isolation, validation, round-trip persistence, revision
conflicts and stripping of forged proof metadata. Unit tests compare all 154 canonical Pauli
matrices against independent Python fixtures and test generic dimensions against tensor Pauli
matrices. Downloaded evidence bytes remain unchanged.

This is an independent private Sites source checkout. Publishing it does not push the parent
Lean repository or distribute manuscript files. `.openai/hosting.json` retains the existing
Site identity. Database migrations are packaged with the built Worker.
