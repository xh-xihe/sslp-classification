import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {canonicalJSON,inputDigest,isTerminal,parseConnection,serviceRequest} from '../app/lib/jobs.ts';
const data=JSON.parse(readFileSync(new URL('../app/data/class36.json',import.meta.url)));

test('browser input hash matches the Python canonical code digest',async()=>{
  assert.equal(await inputDigest(data.instance),'6e62b1c392be0da7bd5d2b12b81136b138b2735d689f327a658f6d5bb14ef7eb');
  const changed=structuredClone(data.instance);changed.words[0][0].coordinates[2]*=-1;
  assert.notEqual(await inputDigest(changed),await inputDigest(data.instance));
  assert.equal(canonicalJSON({b:2,a:[1,3]}),'{"a":[1,3],"b":2}');
  for(const value of [NaN,Infinity,1.5,Number.MAX_SAFE_INTEGER+1,undefined])assert.throws(()=>canonicalJSON(value));
});

test('pairing accepts only a fixed-size key and loopback port',()=>{
  const token='a'.repeat(43);
  assert.deepEqual(parseConnection(`#sslp_key=${token}`),{token,port:8766});
  assert.deepEqual(parseConnection(`#sslp_key=${token}&sslp_port=9000`),{token,port:9000});
  for(const hash of ['',`#sslp_key=${token.slice(1)}`,`#sslp_key=${token}&sslp_port=99999`,`#sslp_key=${token}&sslp_port=443`,`#sslp_key=${token}&sslp_port=8766@evil.invalid`])assert.equal(parseConnection(hash),null);
});

test('cancelled, expired and interrupted jobs are terminal without implying proof success',()=>{
  for(const state of ['completed','cancelled','timeout','failed','interrupted'])assert.equal(isTerminal(state),true);
  for(const state of ['running','queued','cancelling'])assert.equal(isTerminal(state),false);
});

test('service requests keep credentials on loopback and reject arbitrary paths',async(t)=>{
  const calls=[];
  t.mock.method(globalThis,'fetch',async(url,options)=>{calls.push({url,options});return new Response('{}')});
  const connection={token:'a'.repeat(43),port:8766};
  await serviceRequest(connection,'/v1/jobs',{kind:'exact'});
  assert.equal(calls[0].url,'http://127.0.0.1:8766/v1/jobs');
  assert.equal(calls[0].options.credentials,'omit');
  assert.equal(calls[0].options.headers.Authorization,'Bearer '+connection.token);
  assert.equal(calls[0].options.body,'{"kind":"exact"}');
  for(const path of ['https://evil.invalid','/v1/status?token=x','/connect','/v1/jobs/../private'])await assert.rejects(()=>serviceRequest(connection,path));
  assert.equal(calls.length,1);
});

test('expired connection and queue limits produce actionable errors',async(t)=>{
  const connection={token:'a'.repeat(43),port:8766};
  const mock=t.mock.method(globalThis,'fetch',async()=>new Response('{}',{status:401}));
  await assert.rejects(()=>serviceRequest(connection,'/v1/status'),/Connection expired/);
  mock.mock.mockImplementation(async()=>new Response('{}',{status:429}));
  await assert.rejects(()=>serviceRequest(connection,'/v1/status'),/queue is full/);
});
