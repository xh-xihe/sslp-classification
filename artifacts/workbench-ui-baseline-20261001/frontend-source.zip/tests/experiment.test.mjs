import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {analyzeGate,initialExperiment,isCanonical,momentSlice,parseExperiment,phaseWords,exportCode,solveMomentSlice} from '../app/lib/experiment.ts';
import {checkKL,compressionTerms,simulate,zero,add} from '../app/lib/quantum.ts';
const data=JSON.parse(readFileSync(new URL('../app/data/class36.json',import.meta.url)));
const fixtures=JSON.parse(readFileSync(new URL('./fixtures/phase-scenarios.json',import.meta.url)));
const plain=value=>JSON.parse(JSON.stringify(value,(_,v)=>typeof v==='bigint'?Number(v):v));
for(const scenario of fixtures.scenarios)test(`${scenario.name}: all 154 matrices and transformed amplitudes agree with Python`,()=>{
  const words=phaseWords(data.instance.words,scenario.quarterPhases);
  assert.deepEqual(words,scenario.words);
  const result=checkKL(words);
  assert.equal(result.normalized,scenario.normalized);
  assert.deepEqual(plain(result.rows),scenario.kl);
});
test('every displayed Pauli contribution sums to the independent matrix entry',()=>{
  const scenario=fixtures.scenarios.find(s=>s.name==='mixed_quarter_phases');
  const words=phaseWords(data.instance.words,scenario.quarterPhases);
  for(const row of scenario.kl)for(let bra=0;bra<2;bra++)for(let ket=0;ket<2;ket++){
    const sum=compressionTerms(words,row.x_mask,row.z_mask,bra,ket).reduce((total,t)=>add(total,t.coordinates),zero());
    assert.deepEqual(plain(sum),row.matrix_coordinates[bra][ket]);
  }
});
test('constant support residues characterize preservation, including trivial and changed gates',()=>{
  const angles=[[1,1,1,1,2,3],[4,4,4,4,3,2],[0,0,0,0,0,0],[1,1,1,1,1,3],...[1,2,3,4,5].map(k=>Array.from({length:6},(_,i)=>(k+i*i)%5))];
  for(const a of angles){
    const gate=analyzeGate(data.instance.words,a);
    const s0=simulate(data.instance.words,0,0,1,6,a),s1=simulate(data.instance.words,180,0,1,6,a);
    assert.equal(gate.preserves,s0.leakage<1e-12&&s1.leakage<1e-12);
    if(gate.preserves){
      for(const [i,s] of [s0,s1].entries()){
        assert.ok(Math.abs(s.projection[i][0]-Math.cos(2*Math.PI*gate.logicalResidues[i]/5))<1e-12);
        assert.ok(Math.abs(s.projection[i][1]-Math.sin(2*Math.PI*gate.logicalResidues[i]/5))<1e-12);
      }
    }else assert.ok(gate.witness.some(w=>w!==null));
  }
  assert.equal(analyzeGate(data.instance.words,angles[0]).relativeResidue,4);
  assert.equal(analyzeGate(data.instance.words,angles[1]).relativeResidue,1);
  assert.equal(analyzeGate(data.instance.words,angles[2]).relativeResidue,0);
});
test('probability slice is normalized and uniquely feasible at 3/5 on the displayed rational grid',()=>{
  assert.deepEqual(solveMomentSlice(data.instance.words),{status:'unique',numerator:3,denominator:5});
  assert.deepEqual(solveMomentSlice([data.instance.words[0],data.instance.words[0]]),{status:'interval'});
  for(let mass=0;mass<=100;mass++){
    const result=momentSlice(data.instance.words,mass);
    assert.equal(result.rows.length,22);
    assert.deepEqual(result.rows.find(r=>r.mask===0).values,[600,600]);
    assert.deepEqual(result.rows.find(r=>r.mask===16).values,[5*mass,600-5*mass]);
    assert.equal(result.passed,mass===60);
    assert.ok(result.weights.every(w=>w.every(p=>p>=0)));
  }
  // Compare every moment at t=3/5 with probabilities computed from the original
  // integer-coordinate fixture, rather than the slice's group assignment.
  const result=momentSlice(data.instance.words,60);
  for(const row of result.rows){
    for(let i=0;i<2;i++){
      let value=0;
      for(const a of data.instance.words[i]){
        const bits=[...a.bits].reduce((s,b,k)=>s+(Number(b)<<k),0);
        if((bits&row.mask)===row.mask){const c=a.coordinates;value+=c[0]**2+2*c[1]**2+3*c[2]**2+6*c[3]**2+c[4]**2+2*c[5]**2+3*c[6]**2+6*c[7]**2;}
      }
      assert.equal(row.values[i],value*5);
    }
  }
});
test('experiment import rejects malformed, unbounded and noninteger inputs; does not import evidence',()=>{
  const e=initialExperiment();
  assert.deepEqual(parseExperiment(JSON.stringify(e)),e);
  const withEvidence={...e,kernel_status:'passed',html:'<script>bad</script>'};
  assert.deepEqual(parseExperiment(JSON.stringify(withEvidence)),e);
  for(const bad of [{...e,angles:[1,1,1,1,true,3]},{...e,theta:Infinity},{...e,phi:360},{...e,lpMass:-1},{...e,angles:[1]},{...e,angles:[1,1,1,1,1.5,3]},{...e,quarterPhases:[[0],Array(12).fill(0)]},{...e,quarterPhases:[Array(12).fill(4),Array(12).fill(0)]},{...e,case_id:'another-case'},null,[]])assert.throws(()=>parseExperiment(JSON.stringify(bad)));
  assert.throws(()=>parseExperiment('{broken'));assert.throws(()=>parseExperiment(' '.repeat(16001)));
});
test('export contains the actual modified amplitudes and a usable target residue convention',()=>{
  const e=initialExperiment();e.quarterPhases[0][0]=2;
  const code=exportCode(data.instance,e);assert.equal(code.words[0][0].coordinates[2],-2);
  assert.equal(isCanonical(e),false);assert.equal(checkKL(code.words).passed,false);
  e.angles=[4,4,4,4,3,2];assert.deepEqual(exportCode(data.instance,e).gate.logical_residues,[0,1]);
  e.angles=[1,1,1,1,1,3];assert.deepEqual(exportCode(data.instance,e).gate.logical_residues,[0,4]);
  assert.deepEqual(data.instance.gate.angles,[1,1,1,1,2,3]);
});
test('proof viewer uses the exact downloaded certificate and correct theorem line numbers',()=>{
  const certificate=JSON.parse(readFileSync(new URL('../app/data/certificate.json',import.meta.url)));
  const bytes=readFileSync(new URL('../public/downloads/Certificate.lean',import.meta.url));
  assert.equal(createHash('sha256').update(bytes).digest('hex'),certificate.sha256);
  assert.equal(certificate.sha256,data.evidence.kernel.certificate_sha256);
  assert.deepEqual(certificate.lines,bytes.toString('utf8').split(/\r\n|\n|\r/).slice(0,-1));
  assert.equal(Object.keys(certificate.roots).length,7);
  for(const [root,line] of Object.entries(certificate.roots))assert.ok(certificate.lines[line-1].startsWith('theorem '+root.split('.').at(-1)+' '));
});
