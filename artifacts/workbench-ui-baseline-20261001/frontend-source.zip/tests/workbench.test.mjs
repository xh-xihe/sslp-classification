import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {blankCode,parseCode,validateCode,validateProject,checkCode,codeKey,exactText} from '../app/lib/workbench.ts';
import {initialExperiment} from '../app/lib/experiment.ts';
const data=JSON.parse(readFileSync(new URL('../app/data/class36.json',import.meta.url)));
test('legacy experiment files remain usable as research inputs',()=>{
  const e=initialExperiment();e.quarterPhases[0][0]=2;
  const imported=parseCode(JSON.stringify(e));assert.equal(imported.words[0][0].coordinates[2],-2);
  assert.equal(checkCode(imported).passed,false);
});
test('general engine preserves every independently computed canonical Pauli matrix',()=>{
  const code=parseCode(JSON.stringify(data.instance)),result=checkCode(code);
  assert.equal(result.passed,true);assert.equal(result.diagonalAction,true);
  assert.deepEqual(result.fibers,[[0],[4]]);assert.equal(result.kernel,'not_run');
  assert.deepEqual(JSON.parse(JSON.stringify(result.rows,(_,v)=>typeof v==='bigint'?Number(v):v)),data.exact.kl);
});
test('arbitrary dimensions and denominator: normalized repetition code detects its Z failure',()=>{
  const code=blankCode(),result=checkCode(code);
  assert.equal(result.normalized,true);assert.equal(result.passed,false);assert.equal(result.rows.length,10);
  assert.equal(result.rows.find(r=>r.pauli==='Z1').passed,false);
  assert.deepEqual(result.rows.find(r=>r.pauli==='Z1').matrix_coordinates.map(r=>r.map(c=>c[0])),[[1n,0n],[0n,-1n]]);
  const rankOne={...code,n:1,k:1,distance:2,denominator:2,angles:[0],words:[[{bits:'0',coordinates:[0,1,0,0,0,0,0,0]}]]};
  assert.equal(checkCode(rankOne).passed,true);
  rankOne.denominator=3;assert.equal(checkCode(rankOne).normalized,false);
});
test('K=4 full basis compressions agree with independent tensor Pauli action for all two-qubit operators',()=>{
  const coordinates=[1,0,0,0,0,0,0,0];
  const code={schema:'sslp.research-code.v1',n:2,k:4,distance:3,denominator:1,q:2,angles:[0,0],words:['00','10','01','11'].map(bits=>[{bits,coordinates}])};
  const result=checkCode(code);assert.equal(result.rows.length,16);assert.equal(result.normalized,true);
  const one={I:[[[1,0],[0,0]],[[0,0],[1,0]]],X:[[[0,0],[1,0]],[[1,0],[0,0]]],Y:[[[0,0],[0,-1]],[[0,1],[0,0]]],Z:[[[1,0],[0,0]],[[0,0],[-1,0]]]};
  for(const r of result.rows)for(let i=0;i<4;i++)for(let j=0;j<4;j++){
    let v=[1,0];for(let bit=0;bit<2;bit++){
      const label=(r.x_mask>>bit&1)?(r.z_mask>>bit&1?'Y':'X'):(r.z_mask>>bit&1?'Z':'I');
      const w=one[label][i>>bit&1][j>>bit&1];v=[v[0]*w[0]-v[1]*w[1],v[0]*w[1]+v[1]*w[0]];
    }
    assert.deepEqual(r.matrix_coordinates[i][j],[BigInt(v[0]),0n,0n,0n,BigInt(v[1]),0n,0n,0n]);
  }
});
test('editor changes invalidate input identity; sign changes keep probability but can break KL',()=>{
  const code=parseCode(JSON.stringify(data.instance)),key=codeKey(code);
  code.words[0][0].coordinates=code.words[0][0].coordinates.map(c=>-c);
  assert.notEqual(codeKey(code),key);assert.equal(checkCode(code).normalized,true);assert.equal(checkCode(code).passed,false);
  const other=structuredClone(code);other.distance=2;assert.notEqual(codeKey(code),codeKey(other));
});
test('general imports reject ambiguity and bounds and strip purported evidence',()=>{
  const base=blankCode();
  for(const change of [{n:7},{k:0},{distance:4},{denominator:0},{q:1},{angles:[0,0,2]},{words:[base.words[0],base.words[0].concat(base.words[0])]}])assert.throws(()=>validateCode({...base,...change}));
  assert.equal('kernel' in validateCode({...base,kernel:'passed'}),false);
  const wrong=structuredClone(data.instance);wrong.amplitude_encoding.basis.reverse();assert.throws(()=>parseCode(JSON.stringify(wrong)));
  assert.equal(exactText([0n,0n,6n,0n,0n,0n,0n,0n],120),'(1√3)/20');
});
test('project round trips retain research inputs and notes without importing credentials or proof status',()=>{
  const p={id:crypto.randomUUID(),title:'Research',notes:'Conjecture',code:blankCode(),snapshots:[{id:crypto.randomUUID(),label:'Run 1',createdAt:new Date().toISOString(),code:blankCode()}]};
  assert.deepEqual(validateProject(JSON.parse(JSON.stringify(p))),p);
  const injected=validateProject({...p,token:'secret',kernel:'passed',snapshots:p.snapshots.map(s=>({...s,report:{passed:true}}))});
  assert.deepEqual(injected,p);
  assert.throws(()=>validateProject({...p,snapshots:[p.snapshots[0],p.snapshots[0]]}));
  assert.throws(()=>validateProject({...p,title:''}));
});
