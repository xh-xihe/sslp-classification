// Run against the built local Worker, never against a published Site.
import assert from 'node:assert/strict';
import {blankCode} from '../app/lib/workbench.ts';
const origin='http://127.0.0.1:5174';
const owner='workbench-test-'+crypto.randomUUID(),other=owner+'-other';
const request=async(path='',body,identity=owner,writeOrigin=origin)=>{
  const response=await fetch(origin+'/api/projects'+path,{method:body?'POST':'GET',headers:{...(identity?{'oai-authenticated-user-id':identity}:{}),...(body?{'Content-Type':'application/json',Origin:writeOrigin}:{})},body:body?JSON.stringify(body):undefined});
  return {status:response.status,body:await response.json()};
};
const project={id:crypto.randomUUID(),title:'API integration test',notes:'A durable note',code:blankCode(),snapshots:[{id:crypto.randomUUID(),label:'Run 1',createdAt:new Date().toISOString(),code:blankCode()}]};
assert.equal((await request('',undefined,null)).status,401);
assert.equal((await request('',{project,revision:0},null)).status,401);
assert.equal((await request('',{project,revision:0},owner,'https://unrelated.invalid')).status,403);
assert.equal((await request('',{project:{...project,code:{...project.code,n:7}},revision:0})).status,400);
const created=await request('',{project:{...project,kernel_status:'passed',token:'not-a-real-token'},revision:0});
assert.equal(created.status,200);assert.equal(created.body.revision,1);
const loaded=await request('?id='+project.id);assert.deepEqual(loaded.body.project,project);
assert.equal((await request('?id='+project.id,undefined,other)).status,404);
assert.deepEqual((await request('',undefined,other)).body.projects,[]);
assert.equal((await request('',{project,revision:0})).status,409);
const updated={...project,notes:'A revised note'};
assert.equal((await request('',{project:updated,revision:1})).body.revision,2);
assert.equal((await request('',{project,revision:1})).status,409);
assert.deepEqual((await request('?id='+project.id)).body.project,updated);
assert.equal((await request()).body.projects[0].revision,2);
console.log('Project API passed: authentication, ownership, input validation, durable save/reload, conflict rejection and proof-status stripping.');
