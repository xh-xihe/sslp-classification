import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {checkKL,compressed,simulate,mask,multiply,conjugate} from '../app/lib/quantum.ts';
const data=JSON.parse(readFileSync(new URL('../app/data/class36.json',import.meta.url)));
test('download bytes retain their recorded certificate and ZIP hashes',()=>{
  const read=name=>readFileSync(new URL('../public/downloads/'+name,import.meta.url));
  const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
  const integrity=JSON.parse(read('integrity.json'));
  assert.equal(sha(read('Certificate.lean')),data.evidence.kernel.certificate_sha256);
  assert.equal(sha(read('class36-verification.zip')),integrity.bundle_sha256);
  assert.deepEqual(JSON.parse(read('case.json')),data.instance);
  assert.deepEqual(JSON.parse(read('evidence.json')),data.evidence);
});
test('all 154 browser matrices equal the independently generated exact Python fixture',()=>{
  const result=checkKL(data.instance.words);
  assert.equal(result.passed,true);assert.equal(result.rows.length,154);
  assert.deepEqual(JSON.parse(JSON.stringify(result.rows,(_,v)=>typeof v==='bigint'?Number(v):v)),data.exact.kl);
});
test('sign perturbation preserves norm but produces a concrete KL failure',()=>{
  const words=structuredClone(data.instance.words);words[0][0].coordinates=words[0][0].coordinates.map(x=>-x);
  const result=checkKL(words);assert.equal(result.normalized,true);assert.equal(result.passed,false);
  assert.ok(result.rows.some(row=>!row.passed));
});
test('leftmost bit is qubit 1; Y follows i X Z',()=>{
  assert.equal(mask('100000'),1);assert.equal(mask('000001'),32);
  const coordinates=[1,0,0,0,0,0,0,0];
  const matrix=compressed([[{bits:'000000',coordinates}],[{bits:'100000',coordinates}]],1,1);
  assert.equal(matrix[0][1][4],-1n);assert.equal(matrix[1][0][4],1n);
});
test('field multiplication and conjugation retain radical and imaginary signs',()=>{
  const a=[0n,1n,0n,0n,0n,0n,0n,1n];
  assert.deepEqual(multiply(conjugate(a),a),[8n,0n,0n,0n,0n,0n,0n,0n]);
});
test('both complete gates act on arbitrary logical superpositions with correct relative phase',()=>{
  for(const theta of [0,37,90,147,180])for(const phi of [0,61,270])for(const power of [1,4]){
    const result=simulate(data.instance.words,theta,phi,power,6,data.instance.gate.angles);
    const angle=(phi+288*power)*Math.PI/180;
    assert.ok(Math.abs(result.totalProbability-1)<1e-12);assert.ok(result.leakage<1e-12);
    assert.ok(Math.abs(result.projection[0][0]-Math.cos(theta*Math.PI/360))<1e-12);
    assert.ok(Math.abs(result.projection[1][0]-Math.sin(theta*Math.PI/360)*Math.cos(angle))<1e-12);
    assert.ok(Math.abs(result.projection[1][1]-Math.sin(theta*Math.PI/360)*Math.sin(angle))<1e-12);
  }
});
test('intermediate states retain probability and may leave code space',()=>{
  for(let stage=0;stage<=6;stage++)assert.ok(Math.abs(simulate(data.instance.words,90,33,1,stage,data.instance.gate.angles).totalProbability-1)<1e-12);
  assert.ok(simulate(data.instance.words,90,33,1,1,data.instance.gate.angles).leakage>0.1);
});
