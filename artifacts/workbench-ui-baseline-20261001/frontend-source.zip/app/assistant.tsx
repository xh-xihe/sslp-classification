"use client";

import {useCallback,useEffect,useRef,useState} from 'react';
import {inputDigest,isTerminal,jobLabels,parseConnection,serviceRequest,type Connection,type Job,type JobResult,type ServiceStatus} from './lib/jobs';

const phaseLabels: Record<string,string> = {connecting_model:'Connecting to model',model:'Model processing',tool:'Running tool',
  exact:'Exact arithmetic',lean:'Checking Lean and dependencies',packaging:'Packaging artifacts',finished:'Preparing results'};
const kindLabels = {agent:'Assistant',exact:'Exact check',lean:'Lean verification'};
const kernelLabels: Record<string,string> = {passed:'Kernel check passed',failed:'Kernel check failed',timeout:'Kernel check timed out',not_run:'Lean not run'};
const modelLabels: Record<string,string> = {answered:'Response received',budget_exhausted:'Budget reached; completed checks retained',provider_error:'Provider failed; completed checks retained'};

export default function ResearchAssistant({code,assistantCode=code}: {code: unknown|null; assistantCode?: unknown|null}) {
  const dialog = useRef<HTMLDialogElement>(null);
  const connectionRef = useRef<Connection|null>(null);
  const [connection,setConnection] = useState<Connection|null>(null);
  const [service,setService] = useState<ServiceStatus|null>(null);
  const [key,setKey] = useState('');
  const [provider,setProvider] = useState('');
  const [question,setQuestion] = useState('Check the KL conditions for this input and explain the results in English. Cite actual tool records and state whether Lean ran.');
  const [allowLean,setAllowLean] = useState(false);
  const [job,setJob] = useState<Job|null>(null);
  const [result,setResult] = useState<JobResult|null>(null);
  const [busy,setBusy] = useState(false);
  const [error,setError] = useState('');
  const [currentHash,setCurrentHash] = useState('');
  const selection = useRef(0);
  const genericCompute=service?.capabilities?.research_code_v1;
  const directCode=genericCompute?.exact&&genericCompute.lean?code:assistantCode;
  const modelCode=genericCompute?.assistant?code:assistantCode;
  const selectedCode=job?.kind==='agent'?modelCode:directCode;
  const exampleBits=(code as {words?: {bits: string}[][]}|null)?.words?.[0]?.[0]?.bits??'000000';

  useEffect(()=>{let valid=true;setCurrentHash('');inputDigest(selectedCode).then(hash=>{if(valid)setCurrentHash(hash)}).catch(()=>{});return()=>{valid=false}},[selectedCode]);

  const connect = useCallback(async(next: Connection)=>{
    setBusy(true);setError('');
    try {
      const status = await (await serviceRequest(next,'/v1/status')).json() as ServiceStatus;
      if(status.schema!=='sslp.job-api.v1') throw new Error('Local service version mismatch.');
      connectionRef.current=next;setConnection(next);setService(status);setProvider(status.default_provider);setKey('');
    } catch(err) {setError(err instanceof Error?err.message:'Connection failed.')}
    finally {setBusy(false)}
  },[]);

  useEffect(()=>{
    if(!window.location.hash.includes('sslp_key='))return;
    const next=parseConnection(window.location.hash);
    window.history.replaceState(null,'',window.location.pathname+window.location.search);
    dialog.current?.showModal();
    if(next)void connect(next);else setError('Invalid connection details. Reopen the local connection page.');
  },[connect]);

  const refresh = useCallback(async()=>{
    const active=connectionRef.current;if(!active)return;
    const status=await (await serviceRequest(active,'/v1/status')).json() as ServiceStatus;
    if(connectionRef.current===active)setService(status);
  },[]);

  useEffect(()=>{
    if(!connection||!job||isTerminal(job.state))return;
    let stopped=false;
    const requestSelection=selection.current;
    let timer: ReturnType<typeof setTimeout>;
    const poll=async()=>{
      try {
        const update=await (await serviceRequest(connection,`/v1/jobs/${job.id}`)).json() as Job;
        if(stopped||requestSelection!==selection.current)return;
        if(isTerminal(update.state)) {
          let report: JobResult|null=null;
          if(update.state==='completed') {
            report=await (await serviceRequest(connection,`/v1/jobs/${job.id}/result`)).json() as JobResult;
            if(report.input_sha256!==update.input_sha256)throw new Error('Result does not match the submitted input.');
          }
          if(stopped||requestSelection!==selection.current)return;
          setResult(report);setJob(update);setError(update.error??'');void refresh().catch(()=>{});
        } else {setJob(update);setError('');}
      } catch(err) {if(!stopped)setError(err instanceof Error?err.message:'Status temporarily unavailable.')}
      if(!stopped)timer=setTimeout(poll,1500);
    };
    timer=setTimeout(poll,800);
    return()=>{stopped=true;clearTimeout(timer)};
  },[connection,job?.id,job?.state,refresh]);

  async function submit(kind: Job['kind']) {
    const input=kind==='agent'?modelCode:directCode;
    if(!connection||!input)return;
    setBusy(true);setError('');
    try {
      const payload={kind,input,...(kind==='agent'?{provider,question,allow_lean:allowLean}:{})};
      const created=await (await serviceRequest(connection,'/v1/jobs',payload)).json() as Job;
      selection.current++;setResult(null);setJob(created);void refresh().catch(()=>{});
    } catch(err){setError(err instanceof Error?err.message:'Submission failed.')}
    finally{setBusy(false)}
  }

  async function selectJob(previous: Job) {
    if(!connection)return;
    const chosen=++selection.current;
    setJob(previous);setResult(null);setError('');
    if(previous.state==='completed') {
      try {
        const report=await (await serviceRequest(connection,`/v1/jobs/${previous.id}/result`)).json() as JobResult;
        if(report.input_sha256!==previous.input_sha256)throw new Error('Result does not match the submitted input.');
        if(chosen===selection.current)setResult(report);
      } catch(err){if(chosen===selection.current)setError(err instanceof Error?err.message:'Could not load this run.')}
    }
  }

  async function cancel() {
    if(!connection||!job)return;
    const chosen=selection.current;
    setBusy(true);
    try {const update=await (await serviceRequest(connection,`/v1/jobs/${job.id}/cancel`,{})).json() as Job;if(chosen===selection.current){setJob(update);setError('')}void refresh().catch(()=>{})}
    catch(err){if(chosen===selection.current)setError(err instanceof Error?err.message:'Could not cancel the job.')}
    finally{setBusy(false)}
  }

  async function download(name: string) {
    if(!connection||!job)return;
    try {
      const response=await serviceRequest(connection,`/v1/jobs/${job.id}/artifacts/${name}`);
      const url=URL.createObjectURL(await response.blob());const link=document.createElement('a');
      link.href=url;link.download=name;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
    } catch(err){setError(err instanceof Error?err.message:'Download failed.')}
  }

  const active=!!job&&!isTerminal(job.state);
  const changed=!!job&&!!currentHash&&job.input_sha256!==currentHash;
  return <>
    <button className="button" aria-haspopup="dialog" aria-controls="research-assistant" onClick={()=>{dialog.current?.showModal();void refresh().catch(()=>{})}}>Assistant{active?' · Running':''}</button>
    <dialog ref={dialog} className="experiment-dialog assistant-dialog" id="research-assistant" aria-labelledby="assistant-title">
      <div className="dialog-heading"><div><h2 id="assistant-title">Compute & assistant</h2><span className="caption">{connection?'Connected to local compute':'Connect a model and Lean on this computer'}</span></div><button className="quiet-button" onClick={()=>dialog.current?.close()}>Close ×</button></div>
      <div className="assistant-body">
        {!connection?<div className="connection-panel">
          <h3>Connect local Qwen and Lean</h3><p>Jobs run on your computer. Open the connection page and paste its connection code below. Your project stays open.</p>
          <a className="button" href="http://127.0.0.1:8766/connect" target="_blank" rel="noreferrer">Open local connection page ↗</a>
          <form className="connection-form" onSubmit={event=>{event.preventDefault();const next=parseConnection(`#sslp_key=${key.trim()}`);if(next)void connect(next);else setError('Paste the full code from the local connection page.')}}>
            <label htmlFor="connection-key">Connection code</label><input id="connection-key" type="password" autoComplete="off" value={key} onChange={event=>setKey(event.target.value)} maxLength={43}/><button className="button primary" disabled={busy||!key.trim()}>Connect</button>
          </form>
          <details className="reading-note"><summary>Start the local companion</summary><p>From the research repository, run <code>python tools/sslp_service.py</code>, then reopen the connection page. Allow local network access if your browser asks. A shared remote compute service is not connected.</p></details>
        </div>:<>
          <div className="assistant-controls"><label htmlFor="assistant-provider">Model</label><select id="assistant-provider" value={provider} onChange={event=>setProvider(event.target.value)} disabled={active||busy}>{service?.providers.map(p=><option key={p.id} value={p.id} disabled={!p.enabled}>{p.model_class==='closed'?'Closed · ':''}{p.model}{p.enabled?'':' (not configured)'}</option>)}</select><button className="quiet-button" disabled={active||busy} onClick={()=>{selection.current++;connectionRef.current=null;setConnection(null);setService(null);setJob(null);setResult(null);setError('')}}>Disconnect</button></div>
          <label className="assistant-question-label" htmlFor="assistant-question">Research question</label><textarea id="assistant-question" value={question} maxLength={8000} rows={3} onChange={event=>setQuestion(event.target.value)} disabled={active||busy}/>
          <div className="assistant-examples"><button className="text-link" disabled={active} onClick={()=>setQuestion(`Negate only the amplitude of |${exampleBits}> in psi_0. Preserve all other amplitudes and gate exponents. Compare current and candidate with exact checks. Inspect the first failed matrix if there is one. Do not assume a sign flip breaks KL. Explain in English, cite actual tool records and state whether Lean ran.`)}>Try an amplitude sign flip</button><label><input type="checkbox" checked={allowLean} disabled={active||busy} onChange={event=>setAllowLean(event.target.checked)}/>Allow one Lean check</label></div>
          {!modelCode&&<p className="caption">Update the local companion to use model tools with this research input.</p>}
          {!directCode&&<p className="caption">Restart the updated local companion and reconnect to enable research-code verification. Existing jobs remain available below.</p>}
          {genericCompute?.lean&&<p className="caption">Input-derived Lean proofs cover normalization, orthogonality, the requested distance bound and diagonal phase action. Inspect each run's actual result and scope.</p>}
          <div className="actions"><button className="button primary" disabled={busy||active||!modelCode||!question.trim()} onClick={()=>void submit('agent')}>Ask assistant</button><button className="button" disabled={busy||active||!directCode} onClick={()=>void submit('exact')}>Run exact check</button><button className="button" disabled={busy||active||!directCode} onClick={()=>void submit('lean')}>Run Lean verification</button></div>
          <p className="caption">Each job snapshots its input. Direct checks need no model; jobs continue after closing this panel. Time limit: {service?.limits.wall_seconds} seconds.</p>
          {job&&<section className="assistant-job" aria-label="Job results">
            <div className="assistant-job-heading"><strong>{kindLabels[job.kind]} · {jobLabels[job.state]}</strong>{active&&<button className="button" disabled={busy||job.state==='cancelling'} onClick={()=>void cancel()}>Cancel job</button>}</div>
            {active&&<p role="status">{phaseLabels[job.progress?.phase??'']??'Waiting'}{job.progress?.round?` · Round ${job.progress.round}`:''}{job.progress?.tool?` · ${job.progress.tool}`:''}</p>}
            <p className="caption">{changed?'The editor has changed. These results describe the previously submitted input.':'Results are bound to the submitted input.'} <code>{job.input_sha256.slice(0,16)}…</code></p>
            {result?.answer&&<div className="assistant-answer"><h3>Model explanation · {modelLabels[result.status??'']??'Result'}</h3><p>{result.answer.text||result.error||'The model did not return a complete response.'}</p><small>Model text is not a proof. {result.answer.citations?.status==='missing'?'Missing tool citations; inspect the records below.':result.answer.citations?.status==='invalid'?'Invalid citations; inspect the actual records.':'Check citations against the tool records below.'}</small></div>}
            {result&&<div className="verification-results"><h3>Verification records</h3>{result.verification.length===0?<p className="caption">No calculation or kernel-check records yet.</p>:result.verification.map(v=><div className="verification-row" key={v.input_sha256}><span>{v.input_sha256===job.input_sha256?'Submitted input':'Candidate input'} · <code>{v.input_sha256.slice(0,10)}</code></span>{v.exact&&<p>KL: {v.exact.kl_passed?'Passed':'Failed'} ({v.exact.pauli_count-v.exact.failed_pauli_count}/{v.exact.pauli_count} Pauli checks passed) · Requested gate support: {v.exact.gate_support_matches_requested_residues?'Passed':'Failed'}</p>}<strong>{kernelLabels[v.kernel.status]??v.kernel.status}</strong>{v.kernel.scope&&<p className="caption">{v.kernel.scope}</p>}{v.kernel.axioms&&<p className="caption">Axioms: {v.kernel.axioms.join(', ')}</p>}</div>)}</div>}
            {!!result?.tools?.length&&<details className="assistant-trace"><summary>Inspect {result.tools.length} tool calls</summary>{result.tools.map(t=><details key={t.id}><summary>{t.id} · {t.name}</summary><pre>{JSON.stringify({arguments:t.arguments,output:t.output},null,2)}</pre></details>)}</details>}
            {job.artifacts&&<div className="actions">{job.artifacts.includes('verification.zip')&&<button className="button" onClick={()=>void download('verification.zip')}>Download verification bundle</button>}{job.artifacts.includes('candidate.json')&&<button className="button" onClick={()=>void download('candidate.json')}>Download candidate</button>}<button className="text-link" onClick={()=>void download('report.json')}>Download report</button></div>}
          </section>}
          {!!service?.jobs.length&&<details className="assistant-history"><summary>Recent jobs · {service.jobs.length}</summary>{service.jobs.map(previous=><button key={previous.id} className="history-job" onClick={()=>void selectJob(previous)}><span>{kindLabels[previous.kind]} · {new Date(previous.created_at*1000).toLocaleString('en-US')}</span><span>{jobLabels[previous.state]}</span></button>)}</details>}
        </>}
        {error&&<p className="assistant-error" role="alert">{error}</p>}
      </div>
    </dialog>
  </>;
}
