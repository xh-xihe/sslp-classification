import {multiply,mask,popcount,type Word} from './quantum.ts';

export const CANONICAL_ANGLES=[1,1,1,1,2,3];
export type Experiment={schema:'sslp.experiment.v2';case_id:'class36-canonical-20260924';angles:number[];quarterPhases:number[][];theta:number;phi:number;lpMass:number};
export function initialExperiment():Experiment{return {schema:'sslp.experiment.v2',case_id:'class36-canonical-20260924',angles:[...CANONICAL_ANGLES],quarterPhases:[Array(12).fill(0),Array(12).fill(0)],theta:90,phi:0,lpMass:60};}
export function parseExperiment(text:string):Experiment{
  if(text.length>16000)throw new Error('实验 JSON 超过 16 KB 限制。');
  let value:unknown;try{value=JSON.parse(text)}catch{throw new Error('JSON 格式不正确。')}
  if(!value||typeof value!=='object'||Array.isArray(value))throw new Error('实验必须是 JSON 对象。');
  const e=value as Record<string,unknown>;
  const integer=(x:unknown,max:number)=>typeof x==='number'&&Number.isInteger(x)&&x>=0&&x<=max;
  if(e.schema!=='sslp.experiment.v2'||e.case_id!=='class36-canonical-20260924')throw new Error('目前仅支持 class 36 的 v2 实验格式。');
  if(!Array.isArray(e.angles)||e.angles.length!==6||!e.angles.every(a=>integer(a,4)))throw new Error('六个相位门参数必须为 0–4 的整数。');
  if(!Array.isArray(e.quarterPhases)||e.quarterPhases.length!==2||!e.quarterPhases.every(w=>Array.isArray(w)&&w.length===12&&w.every(p=>integer(p,3))))throw new Error('每个码字需要 12 个 0–3 的四分之一圈相位。');
  if(!integer(e.theta,180)||!integer(e.phi,359)||!integer(e.lpMass,100))throw new Error('输入态或概率切片参数超出支持范围。');
  // Reconstruct known fields: imported objects never control proof status or output HTML.
  return {schema:'sslp.experiment.v2',case_id:'class36-canonical-20260924',angles:[...e.angles] as number[],quarterPhases:e.quarterPhases.map(w=>[...w]) as number[][],theta:e.theta as number,phi:e.phi as number,lpMass:e.lpMass as number};
}
export function phaseWords(base:Word[],phases:number[][]):Word[]{
  return base.map((word,i)=>word.map((a,j)=>{const phase=Array<bigint>(8).fill(0n),p=phases[i][j];phase[p%2?4:0]=p>=2?-1n:1n;return {...a,coordinates:multiply(a.coordinates.map(BigInt),phase).map(Number)};}));
}
export const isCanonical=(e:Experiment)=>e.angles.every((a,i)=>a===CANONICAL_ANGLES[i])&&e.quarterPhases.every(w=>w.every(p=>p===0));
export const residue=(bits:string,angles:number[])=>[...bits].reduce((sum,b,i)=>sum+Number(b)*angles[i],0)%5;
export function analyzeGate(words:Word[],angles:number[]){
  const supports=words.map(w=>w.filter(a=>a.coordinates.some(c=>c!==0)));
  const fibers=supports.map(w=>Array.from(new Set(w.map(a=>residue(a.bits,angles)))).sort((a,b)=>a-b));
  const preserves=fibers.every(f=>f.length===1);
  const witness=supports.map((w,i)=>fibers[i].length>1?[w[0].bits,w.find(a=>residue(a.bits,angles)!==residue(w[0].bits,angles))!.bits]:null);
  return {fibers,preserves,witness,logicalResidues:preserves?fibers.map(f=>f[0]):null,relativeResidue:preserves?(fibers[1][0]-fibers[0][0]+5)%5:null};
}
export function rational(n:number,d:number):string{let a=Math.abs(n),b=d;while(b)[a,b]=[b,a%b];return n===0?'0':d/a===1?String(n/a):`${n/a}/${d/a}`;}
// A one-dimensional slice of the probability LP: uniform within the six
// anchor points and within the six edge points. This is not the full LP solver.
export function momentSlice(base:Word[],mass:number){
  const denominator=600;
  const weights=base.map(word=>word.map(a=>a.coordinates[2]!==0?mass:100-mass));
  const masks=Array.from({length:64},(_,i)=>i).filter(m=>popcount(m)<=2);
  const rows=masks.map(m=>{const values=base.map((word,i)=>word.reduce((sum,a,j)=>sum+((mask(a.bits)&m)===m?weights[i][j]:0),0));return {mask:m,label:m===0?'1':Array.from({length:6},(_,i)=>m>>i&1?`x${i+1}`:'').join('·'),values,delta:values[0]-values[1],passed:values[0]===values[1]};});
  return {rows,denominator,weights,passed:rows.every(r=>r.passed)};
}
export function solveMomentSlice(base:Word[]):{status:'unique';numerator:number;denominator:number}|{status:'interval'|'infeasible'}{
  const atZero=momentSlice(base,0),atOne=momentSlice(base,100);
  let solution:{numerator:number;denominator:number}|null=null;
  for(let i=0;i<atZero.rows.length;i++){
    const intercept=atZero.rows[i].delta,slope=atOne.rows[i].delta-intercept;
    if(slope===0){if(intercept!==0)return {status:'infeasible'};continue;}
    let numerator=-intercept,denominator=slope;
    if(denominator<0){numerator=-numerator;denominator=-denominator;}
    if(numerator<0||numerator>denominator)return {status:'infeasible'};
    let a=Math.abs(numerator),b=denominator;while(b)[a,b]=[b,a%b];numerator/=a;denominator/=a;
    if(solution&&solution.numerator*denominator!==numerator*solution.denominator)return {status:'infeasible'};
    solution={numerator,denominator};
  }
  return solution?{status:'unique',...solution}:{status:'interval'};
}
export function exportCode<T extends {words:Word[];gate:{q:number;angles:number[];logical_residues:number[]};id:string}>(base:T,e:Experiment){
  const words=phaseWords(base.words,e.quarterPhases),gate=analyzeGate(words,e.angles);
  return {...base,id:isCanonical(e)?base.id:'class36-user-experiment',words,gate:{q:5,angles:[...e.angles],logical_residues:gate.logicalResidues??[0,4]}};
}
