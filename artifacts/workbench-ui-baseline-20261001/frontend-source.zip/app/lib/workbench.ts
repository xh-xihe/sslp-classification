import {compressed, popcount, zero, type Word, type PauliRow} from './quantum.ts';
import {parseExperiment,exportCode} from './experiment.ts';
import template from '../data/class36.json' with {type:'json'};

export const BASIS = ['1','√2','√3','√6','i','i√2','i√3','i√6'];
export type CodeInput = {
  schema: 'sslp.research-code.v1'; n: number; k: number; distance: number;
  denominator: number; q: number; angles: number[]; words: Word[];
};
export type Snapshot = {id: string; label: string; createdAt: string; code: CodeInput};
export type Project = {id: string; title: string; notes: string; code: CodeInput; snapshots: Snapshot[]};
const object = (v: unknown): Record<string,unknown> => {
  if (!v || typeof v !== 'object' || Array.isArray(v)) throw new Error('Expected a JSON object.');
  return v as Record<string,unknown>;
};
const integer = (v: unknown, low: number, high: number, label: string) => {
  if (!Number.isSafeInteger(v) || (v as number) < low || (v as number) > high) throw new Error(`${label} must be an integer from ${low} to ${high}.`);
  return v as number;
};
const boundedText = (v: unknown, max: number, label: string) => {
  if (typeof v !== 'string' || v.length > max) throw new Error(`${label} must be text with at most ${max} characters.`);
  return v;
};
export function validateCode(value: unknown): CodeInput {
  const v = object(value);
  if (v.schema !== 'sslp.research-code.v1') throw new Error('Expected sslp.research-code.v1. Use the code template to see the format.');
  const n=integer(v.n,1,6,'Qubit count'), k=integer(v.k,1,4,'Logical dimension');
  if (k > 2 ** n) throw new Error('Logical dimension exceeds the physical dimension.');
  const distance=integer(v.distance,1,Math.min(3,n+1),'Target distance');
  const denominator=integer(v.denominator,1,1000000,'Squared amplitude denominator');
  const q=integer(v.q,2,64,'Phase modulus');
  if (!Array.isArray(v.angles) || v.angles.length!==n) throw new Error(`Expected ${n} phase exponents.`);
  const angles=v.angles.map(a=>integer(a,0,q-1,'Phase exponent'));
  if (!Array.isArray(v.words) || v.words.length!==k) throw new Error(`Expected ${k} logical words.`);
  const words=v.words.map((w,i)=>{
    if (!Array.isArray(w) || !w.length || w.length>2**n) throw new Error(`Word ${i} requires 1 to ${2**n} amplitude entries.`);
    const seen=new Set<string>();
    return w.map(entry=>{
      const a=object(entry);
      if (typeof a.bits!=='string' || !new RegExp(`^[01]{${n}}$`).test(a.bits)) throw new Error(`Word ${i}: each basis string must have ${n} bits.`);
      if (seen.has(a.bits)) throw new Error(`Word ${i}: duplicate basis string ${a.bits}.`);
      seen.add(a.bits);
      if (!Array.isArray(a.coordinates) || a.coordinates.length!==8) throw new Error('Each amplitude requires eight integer coordinates.');
      return {bits:a.bits,coordinates:a.coordinates.map(c=>integer(c,-1000000,1000000,'Amplitude coordinate'))};
    });
  });
  return {schema:'sslp.research-code.v1',n,k,distance,denominator,q,angles,words};
}
export function parseCode(text: string): CodeInput {
  if (text.length>100000) throw new Error('Code input exceeds 100 KB.');
  const v=object(JSON.parse(text));
  if (v.schema==='sslp.experiment.v2') {
    try {return parseCode(JSON.stringify(exportCode(template.instance,parseExperiment(text))));}
    catch {throw new Error('Invalid legacy experiment. Expected the Class 36 v2 format with six mod-5 angles and two sets of twelve quarter-turn phases.');}
  }
  if (v.schema==='sslp.code-instance.v1') {
    const encoding=object(v.amplitude_encoding), gate=object(v.gate);
    const expected=['1','sqrt(2)','sqrt(3)','sqrt(6)','i','i*sqrt(2)','i*sqrt(3)','i*sqrt(6)'];
    if (encoding.common_scale!=='1/(2*sqrt(30))' || JSON.stringify(encoding.basis)!==JSON.stringify(expected)) throw new Error('Unsupported amplitude encoding in the imported adapter file.');
    const conventions=object(v.conventions);
    if (conventions.bitstring!=='leftmost character is qubit 1; integer mask bit 0 is qubit 1' || conventions.pauli!=='i^popcount(x&z) X^x Z^z') throw new Error('Unsupported bit or Pauli convention.');
    return validateCode({schema:'sslp.research-code.v1',n:v.n,k:v.k,distance:v.distance_lower_bound,denominator:120,q:gate.q,angles:gate.angles,words:v.words});
  }
  return validateCode(v);
}
export function validateProject(value: unknown): Project {
  const v=object(value), id=boundedText(v.id,36,'Project ID');
  if (!/^[a-f0-9-]{36}$/.test(id)) throw new Error('Invalid project ID.');
  const title=boundedText(v.title,100,'Project title').trim();
  if (!title) throw new Error('Give the project a title.');
  if (!Array.isArray(v.snapshots) || v.snapshots.length>20) throw new Error('A project supports up to 20 saved runs. Export or fork it to continue.');
  const ids=new Set<string>();
  const snapshots=v.snapshots.map(s=>{
    const r=object(s), id=boundedText(r.id,36,'Run ID'), createdAt=boundedText(r.createdAt,30,'Run date');
    if (!/^[a-f0-9-]{36}$/.test(id)||ids.has(id)||!Number.isFinite(Date.parse(createdAt))) throw new Error('Invalid or duplicate saved run.');
    ids.add(id);
    return {id,label:boundedText(r.label,100,'Run label'),createdAt,code:validateCode(r.code)};
  });
  // Only inputs are accepted. Imported success labels, reports and credentials are discarded.
  return {id,title,notes:boundedText(v.notes,20000,'Research notes'),code:validateCode(v.code),snapshots};
}
export const codeKey = (code: CodeInput) => JSON.stringify(validateCode(code));
export function phaseFibers(code: CodeInput) {
  return code.words.map(w=>[...new Set(w.filter(a=>a.coordinates.some(Boolean)).map(a=>[...a.bits].reduce((sum,b,i)=>sum+Number(b)*code.angles[i],0)%code.q))]);
}
export function checkCode(code: CodeInput) {
  const c=validateCode(code), rows: PauliRow[]=[];
  for(let x=0;x<2**c.n;x++) for(let z=0;z<2**c.n;z++) {
    if(popcount(x|z)>=c.distance) continue;
    const matrix=compressed(c.words,x,z);
    const passed=matrix.every((line,i)=>line.every((cell,j)=>cell.every((v,b)=>v===(i===j?matrix[0][0][b]:0n))));
    const pauli=Array.from({length:c.n},(_,i)=>x>>i&1?(z>>i&1?`Y${i+1}`:`X${i+1}`):(z>>i&1?`Z${i+1}`:'')).join('')||'I';
    rows.push({x_mask:x,z_mask:z,pauli,matrix_coordinates:matrix,matrix_denominator:c.denominator,passed});
  }
  const target=zero();target[0]=BigInt(c.denominator);
  const normalized=rows[0].matrix_coordinates.every((line,i)=>line.every((cell,j)=>cell.every((v,b)=>v===(i===j?target[b]:0n))));
  const fibers=phaseFibers(c);
  return {rows,normalized,passed:normalized&&rows.every(r=>r.passed),fibers,diagonalAction:normalized&&fibers.every(f=>f.length===1),kernel:'not_run' as const};
}
export function exactText(value: bigint[], denominator: number) {
  let divisor=BigInt(denominator);
  for(const v of value){let x=divisor,y=v<0n?-v:v;while(y)[x,y]=[y,x%y];divisor=x;}
  if(value.every(v=>v===0n))return '0';
  const parts=value.flatMap((v,i)=>v===0n?[]:[`${v/divisor}${i?BASIS[i]:''}`]);
  const numerator=parts.join(' + ').replaceAll('+ -','− '), d=BigInt(denominator)/divisor;
  return d===1n?numerator:`(${numerator})/${d}`;
}
export function blankCode(): CodeInput {
  return {schema:'sslp.research-code.v1',n:3,k:2,distance:2,denominator:1,q:2,angles:[0,0,0],words:[[{bits:'000',coordinates:[1,0,0,0,0,0,0,0]}],[{bits:'111',coordinates:[1,0,0,0,0,0,0,0]}]]};
}
export function downloadJSON(value: unknown, filename: string) {
  const url=URL.createObjectURL(new Blob([JSON.stringify(value,(_,v)=>typeof v==='bigint'?v.toString():v,2)],{type:'application/json'}));
  const a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
