// Exact basis index bits: sqrt(2), sqrt(3), i. Amplitude scale 1/sqrt(120).
export type Word = { bits: string; coordinates: number[] }[];
export type Exact = bigint[];
export const zero = (): Exact => Array<bigint>(8).fill(0n);
export const add = (a: Exact, b: Exact): Exact => a.map((x,i)=>x+b[i]);
export const conjugate = (a: Exact): Exact => a.map((x,i)=>i&4?-x:x);
export function multiply(a: Exact,b: Exact): Exact {
  const result=zero();
  for(let i=0;i<8;i++) for(let j=0;j<8;j++) {
    const overlap=i&j;
    const factor=(overlap&1?2n:1n)*(overlap&2?3n:1n)*(overlap&4?-1n:1n);
    result[i^j]+=a[i]*b[j]*factor;
  }
  return result;
}
export const mask = (bits: string) => [...bits].reduce((n,b,i)=>n+(Number(b)<<i),0);
export const popcount = (n: number): number => {let count=0;for(;n;n&=n-1)count++;return count;};
const same = (a: Exact,b: Exact) => a.every((x,i)=>x===b[i]);
export type PauliRow = {x_mask:number;z_mask:number;pauli:string;matrix_coordinates:Exact[][];matrix_denominator:number;passed:boolean};
export function compressionTerms(words: Word[], x:number,z:number,braIndex:number,ketIndex:number) {
  const bra=new Map(words[braIndex].map(a=>[mask(a.bits),a]));
  const phase=zero(), exponent=popcount(x&z)%4;
  phase[exponent%2?4:0]=exponent>=2?-1n:1n;
  return words[ketIndex].flatMap(ket=>{
    const y=mask(ket.bits),left=bra.get(y^x);if(!left)return [];
    let value=multiply(conjugate(left.coordinates.map(BigInt)),multiply(phase,ket.coordinates.map(BigInt)));
    if(popcount(z&y)%2)value=value.map(v=>-v);
    return [{from:ket.bits,to:left.bits,coordinates:value}];
  });
}
export function compressed(words: Word[], x:number,z:number): Exact[][] {
  const maps=words.map(word=>new Map(word.map(a=>[mask(a.bits),a.coordinates.map(BigInt)])));
  const phase=zero(), exponent=popcount(x&z)%4;
  phase[exponent%2?4:0]=exponent>=2?-1n:1n;
  return maps.map(bra=>maps.map(ket=>{
    let total=zero();
    for(const [y,amp] of ket){
      const left=bra.get(y^x);if(!left)continue;
      let term=multiply(conjugate(left),multiply(phase,amp));
      if(popcount(z&y)%2)term=term.map(v=>-v);
      total=add(total,term);
    }
    return total;
  }));
}
export function checkKL(words: Word[]) {
  const rows:PauliRow[]=[];
  for(let x=0;x<64;x++)for(let z=0;z<64;z++){
    if(popcount(x|z)>2)continue;
    const m=compressed(words,x,z);
    const pauli=Array.from({length:6},(_,i)=>x>>i&1?(z>>i&1?`Y${i+1}`:`X${i+1}`):(z>>i&1?`Z${i+1}`:"")).join("")||"I";
    rows.push({x_mask:x,z_mask:z,pauli,matrix_coordinates:m,matrix_denominator:120,
      passed:same(m[0][0],m[1][1])&&same(m[0][1],zero())&&same(m[1][0],zero())});
  }
  const identity=zero();identity[0]=120n;
  const m=rows[0].matrix_coordinates;
  const normalized=same(m[0][0],identity)&&same(m[1][1],identity)&&same(m[0][1],zero())&&same(m[1][0],zero());
  return {rows,normalized,passed:normalized&&rows.every(r=>r.passed)};
}
export function formatExact(a: Exact): string {
  const basis=["","√2","√3","√6","i","i√2","i√3","i√6"];
  if(a.every(v=>v===0n))return "0";
  let divisor=120n;for(const value of a){let x=divisor,y=value<0n?-value:value;while(y)[x,y]=[y,x%y];divisor=x;}
  const numerator=a.map((v,i)=>v===0n?"":`${v/divisor}${basis[i]}`).filter(Boolean).join(" + ").replaceAll("+ -","− ");
  return divisor===120n?numerator:`(${numerator})/${120n/divisor}`;
}
export type Complex = [number,number];
const cmul=(a:Complex,b:Complex):Complex=>[a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]];
const cadd=(a:Complex,b:Complex):Complex=>[a[0]+b[0],a[1]+b[1]];
const norm=(a:Complex)=>a[0]**2+a[1]**2;
const basis=[1,Math.sqrt(2),Math.sqrt(3),Math.sqrt(6)];
export function approximate(coordinates:number[]):Complex {
  return [basis.reduce((s,b,i)=>s+b*coordinates[i],0)/Math.sqrt(120),basis.reduce((s,b,i)=>s+b*coordinates[i+4],0)/Math.sqrt(120)];
}
export function simulate(words:Word[],theta:number,phi:number,power:number,stage:number,angles:number[]) {
  const logical:Complex[]=[[Math.cos(theta*Math.PI/360),0],cmul([Math.sin(theta*Math.PI/360),0],[Math.cos(phi*Math.PI/180),Math.sin(phi*Math.PI/180)])];
  const vectors=words.map(word=>{const v:Complex[]=Array.from({length:64},()=>[0,0]);for(const a of word)v[mask(a.bits)]=[basis.reduce((s,b,i)=>s+b*a.coordinates[i],0)/Math.sqrt(120),basis.reduce((s,b,i)=>s+b*a.coordinates[i+4],0)/Math.sqrt(120)];return v;});
  const state=vectors[0].map((a,x)=>{
    const initial=cadd(cmul(logical[0],a),cmul(logical[1],vectors[1][x]));
    const phase=2*Math.PI/5*angles.slice(0,stage).reduce((s,b,i)=>s+power*b*(x>>i&1),0);
    return cmul(initial,[Math.cos(phase),Math.sin(phase)]);
  });
  const projection=vectors.map(v=>v.reduce<Complex>((sum,a,x)=>cadd(sum,cmul([a[0],-a[1]],state[x])),[0,0]));
  return {state,projection,leakage:Math.max(0,1-projection.reduce((s,a)=>s+norm(a),0)),totalProbability:state.reduce((s,a)=>s+norm(a),0)};
}
