﻿import type { Metadata } from 'next';
import './globals.css';
import './workbench.css';
export const metadata: Metadata = {
  metadataBase: new URL('https://sslp-explorer-class36.xh-xihe.chatgpt.site'),
  title: 'SSLP Workbench | Quantum code research',
  description: 'Create quantum-code projects, edit exact amplitudes, explore phase circuits, compare experiments, and inspect Lean verification records.',
  openGraph: {type:'website',locale:'en_US',siteName:'SSLP Workbench',title:'SSLP Workbench',description:'An interactive research workspace for quantum codes and exact verification.'},
  twitter: {card:'summary',title:'SSLP Workbench',description:'Quantum code projects, exact checks and Lean verification.'},
};
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>){return <html lang="en"><body>{children}</body></html>;}
