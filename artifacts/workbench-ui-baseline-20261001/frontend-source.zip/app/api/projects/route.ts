import {database} from '../../../db';
import {validateProject} from '../../lib/workbench';

export const dynamic='force-dynamic';
const json=(value:unknown,status=200)=>Response.json(value,{status,headers:{'Cache-Control':'no-store'}});
function owner(request:Request) {return request.headers.get('oai-authenticated-user-id');}
export async function GET(request:Request) {
  const user=owner(request);if(!user)return json({error:'Sign in to load your projects.'},401);
  try {
    const id=new URL(request.url).searchParams.get('id');
    if(id){
      const row=await database().prepare('SELECT body, revision, updated_at FROM research_projects WHERE owner = ? AND id = ?').bind(user,id).first<{body:string;revision:number;updated_at:string}>();
      if(!row)return json({error:'Project not found.'},404);
      return json({project:JSON.parse(row.body),revision:row.revision,updatedAt:row.updated_at});
    }
    const result=await database().prepare('SELECT id, title, revision, updated_at AS updatedAt FROM research_projects WHERE owner = ? ORDER BY updated_at DESC').bind(user).all();
    return json({projects:result.results});
  } catch(err){console.error('Project load failed',err);return json({error:'Project storage is unavailable. Your open draft is still available for export.'},503);}
}
export async function POST(request:Request) {
  const user=owner(request);if(!user)return json({error:'Sign in to save your project.'},401);
  // Same-origin JSON writes; the platform injects identity after authentication.
  const origin=request.headers.get('Origin');
  if(!origin || origin!==new URL(request.url).origin)return json({error:'Cross-origin writes are not supported.'},403);
  if(!request.headers.get('Content-Type')?.startsWith('application/json'))return json({error:'JSON required.'},415);
  let input:{project:ReturnType<typeof validateProject>;revision:number};
  try {
    const reader=request.body?.getReader();if(!reader)throw new Error('Missing request body.');
    const decoder=new TextDecoder();let text='',size=0;
    while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>1000000){await reader.cancel();throw new Error('Project exceeds 1 MB.');}text+=decoder.decode(value,{stream:true});}
    text+=decoder.decode();const raw=JSON.parse(text);
    if(!Number.isSafeInteger(raw.revision)||raw.revision<0)throw new Error('Invalid project revision.');
    input={project:validateProject(raw.project),revision:raw.revision};
  }catch(err){return json({error:err instanceof Error?err.message:'Invalid project.'},400);}
  try {
    const {project,revision}=input,updatedAt=new Date().toISOString(),body=JSON.stringify(project);
    const result=revision===0
      ?await database().prepare('INSERT INTO research_projects (owner,id,title,body,revision,updated_at) VALUES (?,?,?,?,1,?) ON CONFLICT (owner,id) DO NOTHING').bind(user,project.id,project.title,body,updatedAt).run()
      :await database().prepare('UPDATE research_projects SET title = ?, body = ?, revision = revision + 1, updated_at = ? WHERE owner = ? AND id = ? AND revision = ?').bind(project.title,body,updatedAt,user,project.id,revision).run();
    if(result.meta.changes!==1)return json({error:'This project changed in another session. Export this draft, then reload the saved project or save a fork.'},409);
    return json({revision:revision+1,updatedAt});
  }catch(err){console.error('Project save failed',err);return json({error:'Could not save. Your draft is unchanged; export it or try again.'},503);}
}
