# Research workbench handoff — 2026-09-28

User direction: build a practical research workbench, not a paper-specific demo. Product UI
must be English; conversation with the user remains Chinese. Keep native Windows execution.

Implemented and privately published in `apps/sslp-explorer` (independent Site repository):

- Project sidebar and Code / Circuit / Checks / Compare / Notebook / Certificates tools.
- General sparse exact input: n=1–6, K=1–4, target d<=3, phase modulus 2–64,
  eight integer coordinates in Z[sqrt(2),sqrt(3),i], common scale 1/sqrt(denominator).
- Exact normalization and KL matrices, term inspection, diagonal-action support test,
  phase-layer playback, logical-state preview, support and encoding-matrix inspection.
- D1 project persistence keyed by platform user ID, explicit save, revision conflicts,
  notes and up to 20 input snapshots; comparison recomputes from saved inputs.
- Project/code/report export, legacy code-instance and experiment imports. Imported proof
  statuses and credentials are stripped. Session storage is temporary draft recovery only.
- English local assistant UI, current-input adapter binding, preserved model/exact/Lean jobs.
  Parent `tools/sslp_service.py` connection page and assistant prompt are now English.
- Canonical evidence downloads are unchanged and retain their verified hashes.

Current Lean adapter is still the canonical six-qubit construction. Generic exact checks
are not generic Lean certification. No manuscript or proof source was changed in this turn.
K=1 KL behavior and the Singleton qualification are explicitly distinguished in results.

Validation: TypeScript and production Worker build passed; 30 frontend mathematical/input
tests passed, including independent Python fixtures and a tensor-Pauli oracle. 28 Python
assistant/job tests passed. Local Worker API integration passed authentication, ownership,
schema rejection, save/reload, conflict handling and forged-proof-status stripping.
The local HTML returned 200 with English metadata. Browser automation could not initialize
(`Invalid browser service environment`), so visual and click-through QA remain unverified.

Final Site source commit: `6283a2f359525279de04afbbe2611f89b11a9a51`.
Project: `appgprj_6ab5a69b70a0819191ccacb377d3ca8c`.
Version: `appgprj_6ab5a69b70a0819191ccacb377d3ca8c~appgver_0aaf6d8f7b748191adf068859a06d82b`.
Deployment: `appgdep_6abaea1a002c81918361a569b17b0d66`, succeeded.
URL: https://sslp-explorer-class36.xh-xihe.chatgpt.site
Owner-only audience retained. Parent GitHub repository was not pushed.

Windows notes: Node is `tmp/web-runtime/node-v24.21.0-win-x64/node.exe`.
The Sites build helper has a Windows npm-shim problem; native `npm run build` succeeded.
The Sites workflow saved/pushed source but its Bash packager failed on Windows paths.
Used the bundled `prepare-site-build.cjs` with a checked fresh staging path and native
Windows `tar.exe`, preserving manifest and generated Drizzle migration. No Linux switch.
Final archive: `tmp/sslp-workbench-20260928-final.tar.gz`.
The owned local Worker preview on port 5174 was stopped after testing.

## Assistant acceptance follow-up — 2026-10-01

The user reported that the first nine manual acceptance items passed. Their
assistant requests `2f31bf7c34434a8f9004ef7e2eed07e8` and
`7d747779450f4f6d8d307f49982edbe8` timed out after 120 seconds on the first
model call, before any tool ran. Ollama logs show other long chat-completion
requests occupying the shared server; the workbench request was waiting for
model availability. The 600-second companion budget is separate from the
120-second per-provider-request timeout. No model/hardware change was needed.

Native Windows / Qwen3 14B checks exposed additional model argument errors:
the old tool description elicited quarter_turns=1 and zero gate angles for a
request to negate an amplitude while preserving the gate. Candidate creation
now preserves gate exponents and requested residues by default; optional
replacement angles remain available. Descriptions explicitly distinguish i
from -1. Matrix inspection can select the first failed Pauli without guessed
masks, and supplies exact matrix strings plus computed KL defects. A bounded
single explanation revision requests missing citations/no-Lean disclosure.
This does not establish arbitrary model prose correctness.

Timeout errors now give the per-request limit and actionable Ollama guidance.
Failed model attempts record their round and elapsed time, and reports say
whether actual verification records were retained. No automatic provider
fallback, model unload, daemon restart, or extension of execution limits was
introduced. New workers load these changes without restarting the companion.
No hosted frontend, manuscript, Lean source or parent GitHub push changed.

Validation: 33 assistant/worker/API/process-boundary regression tests passed.
Final live tests used the same companion HTTP API as the workbench, the user's
exact input hash `668c069a091e54e008405755efdcd651fc66db8fcb20a462b5f39cca55506059`,
and prompt version `sslp.assistant.class36.v5-en`:

- Job `11dbd1cf882143b694d029c7ca7ab071`: 17.625 seconds; actual get_case and
  check_exact; normalization/orthogonality, 154/154 KL checks, requested gate
  support pass; actual citations and no Lean claim.
- Job `09449356b416429bae10b2f5d45ade09`: 28.984 seconds; original 154/154,
  candidate 136/154. Candidate compared field-by-field against the submitted
  input: only psi_0's 000000 amplitude was negated (and candidate ID updated).
  Gate and normalization preserved. Actual inspection returns X1X6 with matrix
  [[0,1/5],[1/5,0]], violating the zero-off-diagonal condition. The final model
  explanation accurately describes this failure and explicitly says Lean not
  run. Both final explanations were inspected; this is not a formal proof of
  model prose or a reliability guarantee for future requests.

Raw final requests, reports, candidate, jobs and structured-check summary:
`artifacts/workbench-acceptance-20260929/assistant-rerun-20261001/verified-153857/`.
Earlier diagnostic reports remain in the parent directory and tmp; some contain
known model mistakes and must not be treated as the final acceptance results.
The user can reopen Assistant to refresh history and inspect the two new jobs;
old failed jobs remain unchanged. No browser click-through QA was claimed.
