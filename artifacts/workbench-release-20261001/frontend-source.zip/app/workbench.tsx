"use client";
import {useEffect,useMemo,useRef,useState} from 'react';
import data from './data/class36.json';
import ResearchAssistant from './assistant';
import {CodeEditor,Circuit,CheckResults,Comparison,Certificates,type Run} from './workbench-panels';
import {blankCode,checkCode,codeKey,downloadJSON,parseCode,phaseFibers,validateProject,type CodeInput,type Project,type Snapshot} from './lib/workbench';

type Tab='Code'|'Circuit'|'Checks'|'Compare'|'Notebook'|'Certificates';
type Saved={id:string;title:string;revision:number;updatedAt:string};
const tabs:Tab[]=['Code','Circuit','Checks','Compare','Notebook','Certificates'];
const canonical=parseCode(JSON.stringify(data.instance));
const fresh=(title:string,code:CodeInput):Project=>({id:crypto.randomUUID(),title,notes:'',code:structuredClone(code),snapshots:[]});
const errorText=(e:unknown)=>e instanceof Error?e.message:'The operation could not be completed.';
async function api(path:string,body?:unknown){
  const response=await fetch(path,{method:body?'POST':'GET',credentials:'same-origin',cache:'no-store',...(body?{headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{})});
  const value=await response.json() as {error?:string;projects:Saved[];project:unknown;revision:number;updatedAt:string};if(!response.ok)throw new Error(value.error??'Project service is unavailable.');return value;
}
export default function Workbench(){
  const [project,setProject]=useState<Project|null>(null),[saved,setSaved]=useState<Saved[]>([]),[revision,setRevision]=useState(0);
  const [tab,setTab]=useState<Tab>('Code'),[savedBody,setSavedBody]=useState(''),[notice,setNotice]=useState(''),[storageError,setStorageError]=useState('');
  const [codeDraft,setCodeDraft]=useState(false);
  const [busy,setBusy]=useState(false),[running,setRunning]=useState(false),[run,setRun]=useState<Run|null>(null);
  const [newTitle,setNewTitle]=useState('Untitled research'),[template,setTemplate]=useState('blank');
  const [importText,setImportText]=useState(''),[importError,setImportError]=useState('');
  const newDialog=useRef<HTMLDialogElement>(null),importDialog=useRef<HTMLDialogElement>(null);
  const live=useRef<Project|null>(null);live.current=project;
  const dirty=!!project&&(JSON.stringify(project)!==savedBody||codeDraft);
  const current=!!project&&!!run&&codeKey(project.code)===codeKey(run.code);
  const compatible=!!project&&project.code.n===6&&project.code.k===2&&project.code.distance===3&&project.code.q===5&&project.code.denominator===120;
  const adapterInput=useMemo(()=>project&&compatible?{...data.instance,id:'workbench-candidate',gate:{q:5,angles:project.code.angles,logical_residues:phaseFibers(project.code).map((r,i)=>r.length===1?r[0]:[0,4][i])},words:project.code.words}:null,[project,compatible]);
  useEffect(()=>{
    let cancelled=false;
    try{
      const raw=sessionStorage.getItem('sslp.workbench.draft');
      if(raw){const restored=JSON.parse(raw),p=validateProject(restored.project);setProject(p);live.current=p;setRevision(Number.isSafeInteger(restored.revision)&&restored.revision>=0?restored.revision:0);setSavedBody('');setNotice('Recovered your open draft. Save it to keep it in your account.');}
    }catch{setNotice('The previous draft could not be recovered. You can import an exported project.');}
    if(!live.current){const p=fresh('Transversal phase study',canonical);setProject(p);live.current=p;}
    api('/api/projects').then(v=>{if(!cancelled)setSaved(v.projects)}).catch(e=>{if(!cancelled)setStorageError(errorText(e))});
    return()=>{cancelled=true};
  },[]);
  useEffect(()=>{if(!project)return;try{sessionStorage.setItem('sslp.workbench.draft',JSON.stringify({project,revision}));}catch{setStorageError('Temporary draft recovery is unavailable. Save or export your project before leaving.');}},[project,revision]);
  useEffect(()=>{const prevent=(e:BeforeUnloadEvent)=>{if(dirty){e.preventDefault();e.returnValue='';}};window.addEventListener('beforeunload',prevent);return()=>window.removeEventListener('beforeunload',prevent)},[dirty]);
  function editCode(code:CodeInput){if(project){setProject({...project,code});setNotice('');}}
  function canReplace(){return !dirty||window.confirm('This project has unsaved changes. Save or export it first to keep them. Discard this draft and continue?');}
  function openProject(p:Project,nextRevision=0){setProject(p);setRevision(nextRevision);setSavedBody(nextRevision?JSON.stringify(p):'');setRun(null);setTab('Code');setCodeDraft(false);setNotice('');}
  async function load(id:string){if(!canReplace())return;setBusy(true);try{const v=await api(`/api/projects?id=${encodeURIComponent(id)}`);openProject(validateProject(v.project),v.revision);setStorageError('');}catch(e){setStorageError(errorText(e))}finally{setBusy(false)}}
  async function save(){if(!project)return;if(codeDraft){setTab('Code');setNotice('Apply the full code definition before saving.');return;}setBusy(true);setStorageError('');const snapshot=structuredClone(project);try{const v=await api('/api/projects',{project:validateProject(snapshot),revision});if(live.current?.id===snapshot.id){setRevision(v.revision);setSavedBody(JSON.stringify(snapshot));}setSaved(s=>[{id:snapshot.id,title:snapshot.title,revision:v.revision,updatedAt:v.updatedAt},...s.filter(p=>p.id!==snapshot.id)]);setNotice('Project saved to your account.');}catch(e){setStorageError(errorText(e))}finally{setBusy(false)}}
  async function execute(){
    if(!project||running)return;if(codeDraft){setTab('Code');setNotice('Apply the full code definition before running checks.');return;}if(project.snapshots.length>=20){setNotice('This project has 20 runs. Export or fork it to start a new series.');return;}
    const code=structuredClone(project.code),projectId=project.id;setRunning(true);setNotice('');await new Promise(resolve=>setTimeout(resolve,20));
    try{const report=checkCode(code),label=`Run ${project.snapshots.length+1}`;setRun({code,report,label});
      const snapshot:Snapshot={id:crypto.randomUUID(),label,createdAt:new Date().toISOString(),code};
      setProject(p=>p?.id===projectId?{...p,snapshots:[...p.snapshots,snapshot]}:p);setTab('Checks');setNotice(`${label} completed. Save the project to retain this input snapshot.`);
    }catch(e){setNotice(errorText(e))}finally{setRunning(false)}
  }
  function importInput(){try{
    if(importText.length>1000000)throw new Error('Import exceeds 1 MB.');const raw=JSON.parse(importText);
    if(raw?.schema==='sslp.project.v1'){const p=validateProject(raw.project);p.id=crypto.randomUUID();p.title=`${p.title.slice(0,90)} (import)`;if(!canReplace())return;openProject(p);}
    else{const code=parseCode(importText);if(!canReplace())return;openProject(fresh('Imported code',code));}
    setImportError('');setImportText('');importDialog.current?.close();setNotice('Imported inputs. Verification results must be recomputed.');
  }catch(e){setImportError(errorText(e))}}
  if(!project)return <div className="wb-loading">Opening research workspace…</div>;
  const summary=current?run!.report:null;
  return <div className="workbench-shell">
    <aside className="project-sidebar">
      <a className="wb-brand" href="/" aria-label="SSLP Workbench home"><span className="brand-symbol">S</span><span>SSLP <b>Workbench</b></span></a>
      <div className="sidebar-section-heading"><span>PROJECTS</span><button aria-label="New project" title="New project" disabled={busy} onClick={()=>newDialog.current?.showModal()}>+</button></div>
      <button className="project-entry active" onClick={()=>setTab('Code')}><span className="project-glyph">◇</span><span><strong>{project.title||'Untitled research'}</strong><small>{dirty?'Unsaved changes':'Saved'} · {project.snapshots.length} runs</small></span></button>
      {saved.filter(p=>p.id!==project.id).map(p=><button className="project-entry" key={p.id} disabled={busy} onClick={()=>void load(p.id)}><span className="project-glyph">◇</span><span><strong>{p.title}</strong><small>{new Date(p.updatedAt).toLocaleDateString('en-US')}</small></span></button>)}
      <button className="sidebar-action" disabled={busy} onClick={()=>{setTemplate('class36');setNewTitle('Transversal phase study');newDialog.current?.showModal()}}>＋ From a template</button>
      <button className="sidebar-action" disabled={busy} onClick={()=>importDialog.current?.showModal()}>↥ Import code or project</button>
      <div className="sidebar-divider"/><div className="sidebar-section-heading"><span>EXPERIMENT RUNS</span><span>{project.snapshots.length}/20</span></div>
      {!project.snapshots.length&&<p className="sidebar-empty">Run a check to capture an input snapshot.</p>}
      <div className="run-list">{[...project.snapshots].reverse().map(s=><button key={s.id} onClick={()=>{setRun({code:s.code,report:checkCode(s.code),label:s.label});setTab('Checks')}}><span>▷ {s.label}</span><small>{new Date(s.createdAt).toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'})}</small></button>)}</div>
      <div className="sidebar-bottom"><span>Exact arithmetic · Lean companion</span><small>Private research workspace</small></div>
    </aside>
    <div className="workbench-main">
      <header className="wb-topbar"><div className="wb-breadcrumb">Workspace <span>/</span> {project.title||'Untitled research'}</div><div className="wb-top-actions"><button className="button" disabled={busy} onClick={()=>void save()}>{busy?'Saving / loading…':'Save project'}</button><button className="button" onClick={()=>downloadJSON({schema:'sslp.project.v1',project},'research-project.json')}>Export</button></div></header>
      <div className="wb-project-heading"><div><label className="sr-only" htmlFor="project-title">Project title</label><input id="project-title" className="project-title-input" maxLength={100} value={project.title} onChange={e=>setProject({...project,title:e.target.value})}/><div className="wb-facts"><span>{project.code.n} qubits</span><span>K = {project.code.k}</span><span>Target d ≥ {project.code.distance}</span><span>ℤ[√2, √3, i]</span></div></div><div className="wb-run-actions"><ResearchAssistant code={adapterInput}/><button className="button primary" disabled={running||project.snapshots.length>=20} onClick={()=>void execute()}>{running?'Computing…':'▷ Run exact checks'}</button></div></div>
      <nav className="wb-tabs" aria-label="Research tools">{tabs.map(t=><button key={t} aria-current={tab===t?'page':undefined} onClick={()=>setTab(t)}>{t}{t==='Compare'&&project.snapshots.length>0&&<span>{project.snapshots.length}</span>}</button>)}</nav>
      {(storageError||notice)&&<div className={`wb-notice ${storageError?'has-error':''}`} role={storageError?'alert':'status'}><span>{storageError||notice}</span>{storageError.includes('Sign in')&&<a href="/signin-with-chatgpt?return_to=/" target="_top">Sign in</a>}<button aria-label="Dismiss message" onClick={()=>{setNotice('');setStorageError('')}}>×</button></div>}
      <div className="wb-surface"><section className="wb-tool-area">
        <div hidden={tab!=='Code'}><CodeEditor key={project.id} code={project.code} onChange={editCode} onImport={()=>importDialog.current?.showModal()} onDraftChange={setCodeDraft}/></div>
        {tab==='Circuit'&&<Circuit code={project.code} onChange={editCode}/>}
        {tab==='Checks'&&(run?<CheckResults run={run} current={current} onRestore={()=>editCode(structuredClone(run.code))}/>:<div className="wb-empty"><span className="empty-symbol">⟨ψ|E|ψ⟩</span><h2>No checks yet</h2><p>Run exact checks to inspect normalization, Pauli compressions and diagonal logical action.</p><button className="button primary" onClick={()=>void execute()}>Run this input</button></div>)}
        {tab==='Compare'&&<Comparison snapshots={project.snapshots} onRestore={code=>{editCode(structuredClone(code));setTab('Code')}}/>}
        {tab==='Notebook'&&<section className="tool-section"><div className="tool-heading"><h2>Research notes</h2><span>Saved with this project</span></div><textarea className="research-notes" aria-label="Research notes" placeholder="Record a conjecture, a failed condition, or the next experiment…" maxLength={20000} value={project.notes} onChange={e=>setProject({...project,notes:e.target.value})}/></section>}
        {tab==='Certificates'&&<Certificates code={project.code}/>}
      </section><aside className="wb-inspector"><div className="inspector-title">CURRENT INPUT</div><dl><dt>Normalization</dt><dd>{summary?(summary.normalized?'Passed':'Failed'):'Not checked'}</dd><dt>KL conditions</dt><dd>{summary?`${summary.rows.filter(r=>r.passed).length} / ${summary.rows.length}`:'Not checked'}</dd><dt>Target distance</dt><dd>{summary?(summary.passed?`d ≥ ${project.code.distance} verified by calculation`:'Not established'):'Not checked'}</dd><dt>Diagonal action</dt><dd>{summary?(summary.diagonalAction?'Established in this basis':'Not established'):'Not checked'}</dd><dt>Lean kernel</dt><dd>Not run in browser</dd></dl>{run&&!current&&<p className="inspector-note">Input changed. Run checks again to update these results.</p>}<div className="inspector-rule"/><h3>Verification adapter</h3><p>{compatible?'The local six-qubit companion accepts this representation. Lean may reject inputs outside its canonical construction.':'Browser checks support this representation. A Lean adapter for this input is not connected yet.'}</p><button className="text-link" onClick={()=>setTab('Certificates')}>Inspect proof coverage →</button><div className="inspector-rule"/><h3>Project actions</h3><button className="sidebar-action" disabled={busy} onClick={()=>{if(!canReplace())return;openProject(fresh(`${project.title.slice(0,90)} (fork)`,project.code));setNotice('Fork created from the current input.')}}>⑂ Fork current input</button><button className="sidebar-action" onClick={()=>downloadJSON(project.code,'code-input.json')}>↓ Export code JSON</button>{saved.some(p=>p.id===project.id)&&<button className="sidebar-action" disabled={busy} onClick={()=>void load(project.id)}>↻ Reload saved project</button>}<p className="inspector-note">Save stores your project in your account. Export keeps a portable copy. Local compute credentials are never saved with a project.</p></aside></div>
      <footer className="wb-statusbar"><span>{running?'Computing exact Pauli matrices…':dirty?'Draft · save to retain changes':'All project changes saved'}</span><span>Browser checks available · Lean runs on your computer</span></footer>
    </div>
    <dialog className="wb-dialog" ref={newDialog} aria-labelledby="new-project-title"><form onSubmit={e=>{e.preventDefault();if(!canReplace())return;openProject(fresh(newTitle.trim()||'Untitled research',template==='class36'?canonical:blankCode()));newDialog.current?.close()}}><div className="dialog-heading"><h2 id="new-project-title">New research project</h2><button type="button" aria-label="Close new project" onClick={()=>newDialog.current?.close()}>×</button></div><label>Project name<input value={newTitle} maxLength={100} onChange={e=>setNewTitle(e.target.value)} required/></label><label>Starting point<select value={template} onChange={e=>setTemplate(e.target.value)}><option value="blank">Editable three-qubit repetition code</option><option value="class36">Six-qubit transversal phase code · Class 36</option></select></label><p>{template==='blank'?'An orthonormal pair to edit. It fails the full distance-2 KL conditions; use it to investigate the failure.':'An example with exact amplitudes and a downloadable Lean certificate. Use it as a starting point for new candidates.'}</p><button className="button primary" type="submit">Create project</button></form></dialog>
    <dialog className="wb-dialog" ref={importDialog} aria-labelledby="import-title"><div className="dialog-heading"><h2 id="import-title">Import code or project</h2><button aria-label="Close import" onClick={()=>importDialog.current?.close()}>×</button></div><p>Import a research-code JSON, a previous code-instance JSON, or an exported project. Only inputs and notes are restored.</p><input type="file" accept=".json,application/json" aria-label="Choose JSON file" onChange={async e=>{const file=e.target.files?.[0];if(!file)return;if(file.size>1000000){setImportError('File exceeds 1 MB.');return;}try{setImportText(await file.text());setImportError('')}catch{setImportError('Could not read this file.')}}}/><label className="sr-only" htmlFor="import-code">Code or project JSON</label><textarea id="import-code" className="json-editor" rows={12} value={importText} maxLength={1000001} onChange={e=>setImportText(e.target.value)}/>{importError&&<p role="alert" className="fail-text">{importError}</p>}<button className="button primary" onClick={importInput}>Validate and import</button></dialog>
  </div>;
}
