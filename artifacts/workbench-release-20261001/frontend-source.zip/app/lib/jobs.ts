export type Connection = {token: string; port: number};
export type JobState = 'queued'|'running'|'cancelling'|'completed'|'failed'|'cancelled'|'timeout'|'interrupted';
export type Job = {id: string; kind: 'agent'|'exact'|'lean'; state: JobState; input_sha256: string;
  provider: string|null; created_at: number; started_at: number|null; finished_at: number|null;
  error: string|null; progress?: {phase: string; tool?: string; round?: number}; artifacts?: string[]};
export type ServiceStatus = {schema: 'sslp.job-api.v1'; default_provider: string;
  providers: {id: string; model: string; model_class: string; enabled: boolean}[]; jobs: Job[];
  limits: {wall_seconds: number; worker_memory_mib: number; concurrent: number}};
export type JobResult = {input_sha256: string; status?: string; error?: string|null;
  answer?: {text: string; kind: string; citations?: {status: string}};
  tools?: {id: string; name: string; arguments: unknown; output: unknown}[];
  verification: {input_sha256: string; exact: {kl_passed: boolean; failed_pauli_count: number;
    pauli_count: number; gate_support_matches_requested_residues: boolean}|null;
    kernel: {status: string; scope?: string; axioms?: string[]; error?: string}}[]};

export const jobLabels: Record<JobState,string> = {queued:'Queued',running:'Running',cancelling:'Cancelling',
  completed:'Completed',failed:'Failed',cancelled:'Cancelled',timeout:'Timed out',interrupted:'Interrupted'};
export const isTerminal = (state: JobState) => ['completed','failed','cancelled','timeout','interrupted'].includes(state);

export function parseConnection(hash: string): Connection|null {
  const params = new URLSearchParams(hash.replace(/^#/, ''));
  const token = params.get('sslp_key') ?? '';
  const rawPort = params.get('sslp_port') ?? '8766';
  if (!/^[A-Za-z0-9_-]{43}$/.test(token) || !/^\d{4,5}$/.test(rawPort)) return null;
  const port = Number(rawPort);
  return port >= 1024 && port <= 65535 ? {token,port} : null;
}

export function canonicalJSON(value: unknown): string {
  if (Array.isArray(value)) return '[' + value.map(canonicalJSON).join(',') + ']';
  if (value !== null && typeof value === 'object') return '{' + Object.keys(value).sort().map(key =>
    JSON.stringify(key) + ':' + canonicalJSON((value as Record<string,unknown>)[key])).join(',') + '}';
  if (typeof value === 'number' && !Number.isSafeInteger(value)) throw new Error('Exact inputs require safe integers.');
  const encoded = JSON.stringify(value);
  if (encoded === undefined) throw new Error('Input contains an unserializable field.');
  return encoded;
}

export async function inputDigest(value: unknown): Promise<string> {
  const bytes = new TextEncoder().encode(canonicalJSON(value));
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2,'0')).join('');
}

export async function serviceRequest(connection: Connection, path: string, body?: unknown): Promise<Response> {
  if (!/^\/v1\/(status|jobs(?:\/[0-9a-f]{32}(?:\/(?:result|cancel|artifacts\/[A-Za-z0-9_.-]+))?)?)$/.test(path)) throw new Error('Invalid job path.');
  let response: Response;
  try {
    response = await fetch(`http://127.0.0.1:${connection.port}${path}`, {
      method: body === undefined ? 'GET' : 'POST', mode: 'cors', credentials: 'omit', cache: 'no-store',
      headers: {'Authorization': `Bearer ${connection.token}`, ...(body === undefined ? {} : {'Content-Type':'application/json'})},
      body: body === undefined ? undefined : JSON.stringify(body), signal: AbortSignal.timeout(12000),
    });
  } catch { throw new Error('Cannot reach local compute. Start the companion and allow local network access in your browser.'); }
  if (!response.ok) {
    if (response.status === 401) throw new Error('Connection expired. Reconnect from the local connection page.');
    if (response.status === 429) throw new Error('The job queue is full. Wait for an active job to finish.');
    throw new Error(`Job request failed (${response.status}).`);
  }
  return response;
}
